#!/bin/bash

grep "ERROR" access.log > error.log

if [ $? -eq 0 ]; then
    echo "Analisis Sukses"
else
    echo "Analisis Gagal"
fi
