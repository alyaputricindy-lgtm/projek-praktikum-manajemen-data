#!/bin/bash

INPUT="transactions.txt"
OUTPUT="processed_transactions.log"
ERROR="error.log"

# Cek file kosong
if [ ! -s "$INPUT" ]; then
    echo "$(date) : File transactions.txt kosong" >> "$ERROR"
    exit 1
fi

# Proses data
while IFS= read -r line
do
    amount=$(echo "$line" | cut -d',' -f3)

    if [ "$amount" -gt 100000 ]; then

        upper=$(echo "$line" | tr '[:lower:]' '[:upper:]')

        grep -Fxq "$upper" "$OUTPUT" || echo "$upper" >> "$OUTPUT"

    fi

done < "$INPUT"
