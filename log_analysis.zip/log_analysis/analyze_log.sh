#!/bin/bash

LOGFILE="user_activity.log"
REPORT="daily_report.txt"
ALERT="alert.log"

TODAY=$(date +%Y-%m-%d)

# cek file ada dan tidak kosong
if [ ! -s "$LOGFILE" ]; then
    echo "ERROR: File log tidak ada atau kosong"
    exit 1
fi

# ambil log hari ini
TODAY_LOG=$(grep "$TODAY" "$LOGFILE")

# hitung login gagal
FAILED_LOGIN=$(echo "$TODAY_LOG" | grep "ACTION=login" | grep "STATUS=FAILED" | wc -l)

# hitung upload sukses
SUCCESS_UPLOAD=$(echo "$TODAY_LOG" | grep "ACTION=upload" | grep "STATUS=SUCCESS" | wc -l)

# top 3 user aktif
TOP_USERS=$(echo "$TODAY_LOG" | \
grep -o "USER=[^|]*" | \
cut -d= -f2 | \
sort | uniq -c | sort -rn | head -3)

# buat laporan
echo "======================================" > "$REPORT"
echo "DAILY ACTIVITY REPORT" >> "$REPORT"
echo "Tanggal: $TODAY" >> "$REPORT"
echo "======================================" >> "$REPORT"
echo "" >> "$REPORT"
echo "Total login gagal: $FAILED_LOGIN" >> "$REPORT"
echo "Total upload sukses: $SUCCESS_UPLOAD" >> "$REPORT"
echo "" >> "$REPORT"
echo "Top 3 user paling aktif:" >> "$REPORT"
echo "$TOP_USERS" >> "$REPORT"

# alert jika login gagal > 10
if [ "$FAILED_LOGIN" -gt 10 ]; then
    echo "[$(date)] ALERT: Terjadi $FAILED_LOGIN login gagal hari ini!" >> "$ALERT"
fi
