#!/bin/bash

USED=$(df /mnt/backupdisk | awk 'NR==2 {print $5}' | sed 's/%//')

SISA=$((100-USED))

echo "Space HDD anda tinggal $SISA%"
