#!/bin/bash

while read user
do
    useradd -m $user

    echo "$user:${user}@123" | chpasswd

    echo "User $user berhasil dibuat"
done < user.txt

