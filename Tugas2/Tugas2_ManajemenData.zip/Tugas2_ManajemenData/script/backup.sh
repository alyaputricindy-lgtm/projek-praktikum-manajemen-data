#!/bin/bash

DATE=$(date +%Y%m%d_%H%M%S)

tar -czf /mnt/backupdisk/backup/backup_$DATE.tar.gz ~/datauji

echo "Backup selesai"
